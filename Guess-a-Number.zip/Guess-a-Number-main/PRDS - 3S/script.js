function checkGuess(){
    console.log("It's working");
    let inputUser = document.getElementById("userGuess").value;
    console.log(inputUser);
}